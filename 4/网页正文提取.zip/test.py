from bs4 import BeautifulSoup
import os

dir_path = input("请输入需要解析的html文件所在文件夹路径：")

if not os.path.exists(dir_path):
    print("输入的文件夹不存在！")
    os.system("pause")
    exit(0)

dir_out_path = input("请输入输出文件夹路径\n输入0则默认在当前文件夹下创建新文件夹out\n若文件夹不存在则将被创建：")

if dir_out_path == "0":
    if not os.path.exists("./out"):
        os.mkdir("./out")
    dir_out_path = "./out"
elif not os.path.exists(dir_out_path):
    os.mkdir(dir_out_path)

files = os.listdir(dir_path)
for f in files:
    if not f.endswith(".html"):
        continue
    out = open(dir_out_path + "\\" + f.split(".")[0] + ".txt", "wt", encoding="utf-8")
    soup = BeautifulSoup(open(dir_path + "\\" + f, encoding="utf-8"), "html.parser")
    title = soup.title.text # title部分
    body = list(map(str.strip, soup.body.text.split("\n"))) # body部分
    link = soup.find_all("a") # 链接
    out.write("title:\n" + title + "\n") # 输出title

	# 输出body
    out.write("\n")
    out.write("body:\n")
    cnt = 0
    is_first = True
    for t in body:
        if t:
            out.write(t + "\n" if t else "")
            cnt = 0
        else:
            if cnt:
                continue
            else:
                cnt += 1
                if is_first:
                    is_first = False
                    continue
                out.write("\n")

	# 输出链接
    out.write("link:\n")
    for l in link:
        if l:
            try:
                out.write(l.text.strip() + " " + l["href"] + "\n")
            except KeyError:
                pass
    out.close()
    del soup

os.system("pause")
