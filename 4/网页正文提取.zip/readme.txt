2127405068孙家扬 信息检索作业四附件使用须知：

作业四标题：网页正文提取
要求：给定HTML文件，将其进行解析并提取出title，body的正文和链接，输出到同名文本文件中。

附件内容：
    test.py

运行：
请确保系统为Windows系统，并且安装有Python3.9版本的Python运行环境。
在运行前，请打开控制台，输入pip show beautifulsoup4，查看Python运行环境是否已经安装beautifulsoup4第三方库。
若未安装，请输入pip install beautifulsoup4，以安装该第三方库，否则无法运行本程序。
双击test.py即可运行程序。