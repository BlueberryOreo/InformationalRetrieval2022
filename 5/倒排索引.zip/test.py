import os
import re
import sys

dic = {}
stopwords = {}
res = {}

if not os.path.exists("./dict.txt.big.txt"):
    print("当前目录（{}）下不存在dict.txt.big.txt。\n".format(os.getcwd()) +
          "请将该词典文件放置于当前目录下后再运行本程序。")
    os.system("pause")
    sys.exit(0)

if not os.path.exists("./stopwords-master"):
    print("当前目录（{}）下不存在包含停用词的词典文件夹stopwords-master。\n".format(os.getcwd()) +
          "请将该文件夹放置于当前目录下后再运行本程序。")
    os.system("pause")
    sys.exit(0)

# 建立分词词典
with open("./dict.txt.big.txt", encoding="utf-8") as f:
    line = f.readline()
    while line:
        word = line.split()[0]
        length = len(word)
        if dic.get(length):
            dic[length].add(word)
        else:
            dic[length] = {word}
        line = f.readline()

keys = list(dic.keys())
keys.sort(reverse=True)
max_len = keys[0]

# 建立废弃单词词典
stopwords_file_lst = os.listdir("./stopwords-master")
for f in stopwords_file_lst:
    if not f.endswith(".txt"):
        continue
    file_name = "./stopwords-master/" + f
    with open(file_name, encoding="utf-8") as ff:
        line = ff.readline()
        while line:
            word = line.strip()
            length = len(word)
            if stopwords.get(length):
                stopwords[length].add(word)
            else:
                stopwords[length] = {word}
            line = ff.readline()


# 分句
def sentence_divide(l_file_path: str):
    l_f = open(l_file_path, encoding="utf-8")
    lines = l_f.readlines()
    # return lines
    l_sentences = []
    split_match = re.compile(r"[\n\s。！？]")
    for l in lines:
        context = re.split(split_match, l)
        if context[0] == 'body:' or context[0] == 'title:':
            continue
        # 去除link部分
        if context[0] == 'link:':
            break
        for c in context:
            if c:
                l_sentences.append(c)
    return l_sentences


# 分词
def word_cut(l_sentences: list):
    for i in range(len(l_sentences)):
        tmp = ""
        index = 0
        # english_cnt = 0
        while index < len(l_sentences[i]):
            # print(index)
            word_len = max_len
            while l_sentences[i][index: index + word_len] not in dic[word_len]:
                word_len -= 1
                if word_len == 1:
                    break
            tmp_word = l_sentences[i][index: index + word_len]
            index += word_len
            # 剔除废弃词语、非法符号和英文
            if (stopwords.get(word_len) and tmp_word in stopwords[word_len]) or (
                    re.findall(r"[\\/:*?\"<>|]", tmp_word)) or "a" <= tmp_word <= "z" or "A" <= tmp_word <= "Z":
                continue
            # 分词
            # if index == 0 or "a" <= tmp_word <= "z" or "A" <= tmp_word <= "Z":
            if index == 0:
                # if english_cnt == 0:
                #     tmp += " " + tmp_word
                #     english_cnt += 1
                # else:
                tmp += tmp_word
            else:
                # english_cnt = 0
                tmp += " " + tmp_word
            # 忽略英语单词， 避免将其拆分成字母
            # if "a" <= tmp_word <= "z" or "A" <= tmp_word <= "Z":
            #     continue
        l_sentences[i] = tmp.strip()
    return l_sentences


# 倒排（初始方法）
# def invert(l_sentences, l_file_name, out_dir):
#     used = set()
#     for s in l_sentences:
#         words = s.split()
#         for w in words:
#             if w in used:
#                 continue
#             used.add(w)
#             w_keys = set(map(lambda x: x[:-4], os.listdir(out_dir)))
#             out_path = out_dir + "\\" + w + ".txt"
#             if w in w_keys:
#                 out_f = open(out_path, "a")
#                 # print(out_path[47:-4], l_file_name)
#                 out_f.write(l_file_name + "\n")
#                 out_f.close()
#             else:
#                 out_f = open(out_path, "wt")
#                 out_f.write(l_file_name + "\n")
#                 out_f.close()


# 倒排（修改后）
def invert(l_sentences, l_file_name):
    # used = set()
    for s in l_sentences:
        words = set(s.split())
        for w in words:
            if res.get(w):
                res[w].add(l_file_name)
            else:
                res[w] = {l_file_name}


if __name__ == "__main__":
    dir_path = input("请输入需要倒排的文件所在的文件夹绝对路径：")
    while not os.path.exists(dir_path):
        dir_path = input("输入的文件夹不存在！请重新输入：")
    dir_out = input("请输入倒排存储的文件夹绝对路径：")
    while not os.path.exists(dir_out):
        dir_out = input("输入的文件夹不存在！请重新输入：")

    file_lst = os.listdir(dir_path)
    cnt = 0
    total = len(file_lst)
    info = ""
    for f in file_lst:
        # 进度
        print("\b" * len(info), end="")
        cnt += 1
        info = "Solved:{:.1f}%".format(cnt / total * 100)
        print(info, end="")
        # if f.startswith("阿"):
        if not f.endswith(".txt"):
            total -= 1
            continue
        # f：文件名
        file_path = dir_path + "\\" + f
        sentences = sentence_divide(file_path)
        # print(sentences)
        after_s = word_cut(sentences)
        # print(after_s)
        invert(after_s, f)

    print()
    # 输出
    cnt = 0
    total = len(res.keys())
    info = ""
    for k in res.keys():
        # 进度
        print("\b" * len(info), end="")
        cnt += 1
        info = "Output:{:.1f}%".format(cnt / total * 100)
        print(info, end="")
        out_name = dir_out + "\\" + k + ".txt"
        with open(out_name, "a") as out:
            for file in res[k]:
                out.write(file + "\n")
    print("\nComplete!")
    os.system("pause")
