#include <iostream>
#include <cmath>
using namespace std;

void outB(int *bin);
int* getBin(int i);

void outC(char *arr, int len){
    for(int i = 0; i < len; i ++){
        printf("%d-", arr[i] + 256);
        outB(getBin(arr[i] + 256));
    }
    cout << endl;
}

void outB(int *bin){
    for(int i = 0; i < 8; i ++){
        cout << bin[i];
    }
    cout << endl;
}

int* getBin(int i){
    int bin[8] = {};
    int index = 7;
    while(i){
        bin[index --] = i % 2;
        i /= 2;
    }
    return bin;
}

int check(char c){
    int* bin = getBin((int)c + 256);
    int index = 0;
    while(bin[index] == 1){
        index ++;
    }
    return index;
}

int main(){

    system("chcp 65001");

    char s1[] = "中";
    char s2[] = "中中";
    char s3[] = "我是中国人";
    char s4[] = "·";
    int i = sizeof(s2);
    cout << i << endl;
    cout << sizeof(s2) / sizeof(s2[0]) << endl;
    cout << sizeof(s3) << endl;
    cout << sizeof(s4) << endl;
    outC(s1, sizeof(s1) / sizeof(s1[0]));
    outC(s2, sizeof(s2) / sizeof(s2[0]));
    outC(s3, sizeof(s3) / sizeof(s3[0]));
    outC(s4, sizeof(s4) / sizeof(s4[0]));

    char c[4] = {233 - 256, 149 - 256, 191 - 256}; //长
    cout << c << endl;

    int l = 0;
    int r = 0;

    cout << check(s1[0]) << endl;
    // while((int)s4[r] != 0){
    //     int *tempBin = getBin(s4[l]);
    // }

    system("pause");
    return 0;
}