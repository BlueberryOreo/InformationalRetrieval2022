2127405068孙家扬 信息检索作业一附件使用须知：

作业一标题：分字
要求：将Sentence.txt中的汉字用/分隔开

附件内容：
    Test.cpp
    Test01.cpp
    Test02.cpp
    out.txt - 输出结果
*其中，Test.cpp为本次作业的主程序源代码。Test01.cpp和Test02.cpp为实验测试用代码，实验内容见实验报告。

源码编译：
请确认系统为Windows系统，并且已安装MinGW的C++编译器。请确认可以在控制台调用C++编译器。
请使用g++编译器对Test.cpp文件进行编译。控制台指令（当前目录下）：g++ Test.cpp -o Test.exe
请使用g++编译器对Test01.cpp文件进行编译。控制台指令（当前目录下）：g++ Test01.cpp -o Test01.exe
请使用g++编译器对Test02.cpp文件进行编译。控制台指令（当前目录下）：g++ Test02.cpp -o Test02.exe

运行：
请在Windows系统上运行Test.exe。运行前请确保当前文件夹下有Science.txt文件，否则可能运行失败。
当出现Process completed.时表示运行成功。结果将输出于out.txt文件中。
请在Windows系统上运行Test01.exe和Test02.exe。