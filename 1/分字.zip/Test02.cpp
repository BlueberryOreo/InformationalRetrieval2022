#include <iostream>
using namespace std;

//十进制转二进制，返回值为int类型数组
int* getBin(int i){
    int bin[8];
    int index = 7;
    while(i){
        bin[index --] = i % 2;
        i /= 2;
    }
    return bin;
}

//获得一个字节的utf-8编码
int getUtf(char c){
    return (int)c + 256;
}

int main(){

    system("chcp 65001");
    string s = "我是中国人。";
    for(int i = 0; i < 2; i ++){
        cout << s[i];
    }

    for(int i = 0; i < 3; i ++){
        cout << s[i];
    }

    system("pause");
    return 0;
}