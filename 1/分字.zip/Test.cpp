#include <iostream>
#include <fstream>
#include <vector>
#include <string>
using namespace std;

//将十进制转换成二进制，大小限制为8bit，返回值为int类型数组
int* getBin(int i){
    static int b[8];
    int index = 7;
    while(i && index >= 0){
        b[index --] = i % 2;
        i /= 2;
    }
    return b;
}

//检查一个字节的编码（是10开头还是110开头还是...）
//返回值说明：
/*
    0:ASCII编码字符
    1:UTF-8 n字节字符的第2~n字节
    2:UTF-8 2字节字符的第一个字节
    3:UTF-8 3字节字符的第一个字节
    4:UTF-8 4字节字符的第一个字节
    以此类推
*/
int check(char c){
    int* bin = getBin((int)c + 256);
    int index = 0;
    while(bin[index] == 1){
        index ++;
    }
    return index;
}

int main(){

    ifstream f("./Sentence.txt");
    ofstream outf("./out.txt");
    if(!f.is_open()){
        cout << "open file failed" << endl;
        system("pause");
        exit(0);
    }
    string temp;
    // int count = 0;
    while(getline(f, temp)){
        int i = -1;
        while(temp[++ i] != 0){
            int l = check(temp[i]); //通过编码规则，获得一个字符的长度
            if(l == 1/* || l == 0*/) continue;

            //保留半角字符
            if(l == 0){
                outf << temp[i];
                continue;
            }

            //其实这个地方我感觉也可以直接输出，都不需要中间存储
            vector<char> c;
            for(int j = i; j < i + l; j ++){
                c.push_back(temp[j]);
            }
            for(int j = 0; j < c.size(); j ++){
                outf << c[j];
            }
            if(temp[i + l] != 0){
                outf << "/";
            }
        }
        outf << endl;

        // count ++;
        // if(count == 10) break;
    }

    f.close();
    outf.close();
    cout << "Process completed." << endl;
    system("pause");

    return 0;
}