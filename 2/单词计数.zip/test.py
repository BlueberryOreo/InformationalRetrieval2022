import re
m = re.compile(r"[a-zA-Z]+")

with open("./sample-en.txt") as f:
    context = f.read()

# print(context)
words = m.findall(context)
words = list(map(str.lower, words))
# print(words)
# total = len(words)

dic = {}
for w in words:
    keys = set(dic.keys())
    if w not in keys:
        dic[w] = 1
    else:
        dic[w] += 1

f = open("./dict.index", "w+")
keys = set(dic.keys())
for k in keys:
    f.write(k + "\t" + str(dic[k]) + "\n")

w = input("请输入要查询的单词：")
while w != "###":
    if w in keys:
        times = dic[w]
    else:
        times = 0
    print(str(times))
    w = input("请输入要查询的单词：")
