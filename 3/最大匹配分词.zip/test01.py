import os

fin = open("./Sentence.txt", encoding="utf-8")
fout = open("./test_out.txt", "w+", encoding="utf-8")
fdic = open("./Dict.txt", encoding="utf-8")

words = fdic.read().split("\n")[1:]
dic = {}
for w in words:
    k = set(dic.keys())
    if len(w) in k:
        dic[len(w)].add(w)
    else:
        dic[len(w)] = {w}

# print(dic)
keys = list(dic.keys())
keys.sort(reverse=True)

# print(keys)
line = fin.readline()

start = 1
while line:
    while start < len(line):
        temp = 0
        while start + keys[temp] >= len(line):
            temp += 1
            if temp >= len(keys):
                temp -= 1
                break
        temp_word = line[start:start + keys[temp]]
        while temp_word not in dic[keys[temp]]:
            temp += 1
            if temp >= len(keys):
                temp -= 1
                break
            temp_word = line[start:start + keys[temp]]
        # print(start, start + keys[temp], keys[temp])
        fout.write(temp_word + " " if temp_word != "\n" else temp_word)
        # print(temp_word + " " if temp_word != "\n" else temp_word)
        # print(temp_word.encode("utf-8"))
        start = start + keys[temp]
    line = fin.readline()
    start = 0

os.system("pause")
