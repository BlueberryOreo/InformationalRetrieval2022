2127405068孙家扬 信息检索作业三附件使用须知：

作业三标题：汉语分词
要求：将Sentence.txt中的词语区分开，用空格隔开，输出到新的文件中。

附件内容：
    test01.py
    evaluate.py
    test02.py
*其中，test01.py、evaluate.py为本次作业的主程序源代码。

运行：
请确保系统为Windows系统，并且安装有Python3.8及以上版本的Python运行环境。运行前，请确保在和test01.py相同路径下存在Dict.txt, Sentence.txt和Answer.txt文件。
双击test01.py、evaluate.py即可运行程序。
请在运行完test01.py后再运行evaluate.py