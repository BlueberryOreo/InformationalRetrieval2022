import os

f1 = open("./test_out.txt", encoding="utf-8-sig")
f2 = open("./Out.txt")

line1 = f1.readline()
line2 = f2.readline()

line = 0
while line1 and line2:
    line += 1
    if len(line1.split()) != len(line2.split()):
        print("in line {}".format(line))
        print("03out:\t\t", line1.split())
        print("Out.txt:\t", line2.split())
        print()
    line1 = f1.readline()
    line2 = f2.readline()

os.system("pause")
