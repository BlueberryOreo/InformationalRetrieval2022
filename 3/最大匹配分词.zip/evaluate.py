import os

test = open("./test_out.txt", encoding="utf-8")
ans = open("./Answer.txt", encoding="utf-8-sig")

line = [test.readline(), ans.readline()]  # [test, ans]
t_total = 0
a_total = 0
correct = 0

while line[0] and line[1]:
    t_case = line[0].split()
    a_case = line[1].split()
    t_total += len(t_case)
    a_total += len(a_case)
    # print(t_case)
    # print(a_case)
    t_count = 0
    a_count = 0
    t = 0
    a = 0
    while t < len(t_case) or a < len(a_case):
        if t == len(t_case) and a < len(a_case):
            if t_case[t - 1] == a_case[a]:
                correct += 1
                break
            a_count += len(a_case[a])
            a += 1
        elif a == len(a_case) and t < len(t_case):
            if a_case[a - 1] == t_case[t]:
                correct += 1
                break
            t_count += len(t_case[t])
            t += 1
        else:
            if t_case[t] == a_case[a]:
                correct += 1
                t_count += len(t_case[t])
                a_count += len(a_case[a])
                t += 1
                a += 1
                continue
            if t_count <= a_count:
                t_count += len(t_case[t])
                t += 1
            else:
                a_count += len(a_case[a])
                a += 1
    line = [test.readline(), ans.readline()]

p = correct / t_total
r = correct / a_total
f = (p * r * 2) / (p + r)
print("正确识别的词数：{}".format(correct))
print("识别出的总体个数：{}".format(t_total))
print("测试集中的总体个数：{}".format(a_total))
print("正确率：{:.5f}".format(p))
print("召回率：{:.5f}".format(r))
print("F值：{:.5f}".format(f))

os.system("pause")

'''
*正确实验结果
**正确识别的词数：20263
**识别出的总体个数：20397
**测试集中的总体个数：20454
**正确率：0.99343
**召回率：0.99066
**F值：0.99204
'''
